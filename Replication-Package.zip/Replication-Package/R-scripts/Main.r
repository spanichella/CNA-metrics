#@Sebastiano Panichella

library(stringr)
library(igraph)
library(sna)
# load required libraries
library(tm)
library(ggplot2)
library(lsa)

#project1
path_project<-"/Users/setup/Documents/APPLICATIONS/APPLICATIONS-2017/ZHAW/TASK-second-round-interview/SLIDES/projects_data_and_scripts/projects/cna_spring-cloud-microservice-example-master" 
project_short_name<- "spring"

#project2
#path_project<-"/Users/setup/Documents/APPLICATIONS/APPLICATIONS-2017/ZHAW/TASK-second-round-interview/SLIDES/projects_data_and_scripts/projects/migr_acmeair-monolithic-java" 
#project_short_name<- "acmeair"

#project3
#path_project<-"/Users/setup/Documents/APPLICATIONS/APPLICATIONS-2017/ZHAW/TASK-second-round-interview/SLIDES/projects_data_and_scripts/projects/migr_cocome-maven-project" 
#project_short_name<- "cocome"

width=18
height=13

#load function 1
source("/Users/setup/Documents/APPLICATIONS/APPLICATIONS-2017/ZHAW/TASK-second-round-interview/SLIDES/projects_data_and_scripts/R-scripts/R-functions/Conceptual-information-microservices-analysis.r")

#load function 2
source("/Users/setup/Documents/APPLICATIONS/APPLICATIONS-2017/ZHAW/TASK-second-round-interview/SLIDES/projects_data_and_scripts/R-scripts/R-functions/Semantic-information-microservices-analysis.r")

#load function 3
source("/Users/setup/Documents/APPLICATIONS/APPLICATIONS-2017/ZHAW/TASK-second-round-interview/SLIDES/projects_data_and_scripts/R-scripts/R-functions/Structure-information-microservices-analysis.r")

structuralCoupling <- computeStructuralSimilarityBetweenFiles(path_project,project_short_name,width,height)

semanticCoupling <- computeSemanticSimilarityBetweenFiles(path_project,project_short_name,width,height)

conceptualCoupling <- computeConceptualSimilarityBetweenFiles(path_project,project_short_name,width,height)


