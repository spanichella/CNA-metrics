#@Sebastiano Panichella

computeConceptualSimilarityBetweenFiles<-function(path_project,project_short_name,width,height){
  
graph_path<-paste(path_project,"/conc_graph.pdf",sep="")

#WE COMPUTED THE STRUCTURAL COUPLING

#let's collect all nodes of the microservices (can be one file or several set of files per microservice..)
path_microservices_info<-paste(path_project,"/Microservices-info.csv", sep="")
microservices_info<-read.csv(path_microservices_info)

microservices_info_classes<- list(microservice=c(), microservice_file=c())
i<-1
for (i in 1:length(microservices_info$Microservice)){
  #initialization<-
  location_folder_microservice<-path_project
  
   #CASE 1: microservices are located in precise folders
    if(microservices_info$Is_Folder[i]=="yes"){
      #all folders in the directory..
      location_folder_microservice <- list.dirs(path_project,full.names = microservices_info$Microservice[i],recursive = TRUE) 
      pattern <- paste("/",microservices_info$Microservice[i],sep="")
      #we detect the folder of the microservices, among all folders in the directory..
      location_folder_microservice<-location_folder_microservice[which(endsWith(location_folder_microservice,pattern))]
      location_folder_microservice<- location_folder_microservice[1]
      #we detect all class files in the folder of the microservices
      class_files<-list.files(location_folder_microservice,pattern = "*.java",recursive = TRUE)
    }
    
    #CASE 2: microservices are actual class files
    if(microservices_info$Is_File[i]=="yes"){
      class_files<- list.files(as.character(microservices_info$Path_File[i]),pattern = as.character(microservices_info$Microservice[i]),recursive = TRUE)
    }
    
      #we collect in the list the information about the class files related to the microservice
      c<-1
        for(c in 1:length(class_files))
        {
          
          pos<- length(microservices_info_classes$microservice)+1
          microservices_info_classes$microservice[pos] <- as.character(microservices_info$Microservice[i])
          # we detect the minimum part of the class and save in the list...
          microservices_info_classes$microservice_file[pos] <- str_extract(class_files[c],"/[A-Z]([A-z]|[0-9])*.java") 
          microservices_info_classes$microservice_file[pos] <- str_sub(microservices_info_classes$microservice_file[pos] ,2,str_length(microservices_info_classes$microservice_file[pos]))
        }
  print(paste("preprocessing",i, "out of", length(microservices_info$Microservice),"microservices"))
}

#we generate the log file from the git repository...
   # we determine the git repository of the project
   path_git_repository<- list.dirs(path_git_repositories,recursive = FALSE)
   path_git_repository<- path_git_repository[which(str_detect(path_git_repository,project_short_name))]
   #we define the command to generate the log file:
   path_log_file<-paste(path_git_repository,"/log.txt",sep="")
   command<- paste("cd ",path_git_repository," && git log --stat --date iso > ",path_log_file, sep="")
   system(command)
    # we load the log information...
    con <- file(path_log_file, "r", blocking = FALSE)
    log_file<-readLines(con) # empty
    close(con)
  
log_file[which(str_detect(log_file, "EJBExceptionHelper.java"))]

#we select only the relevant information from the log:
log_file <- log_file[which(str_detect(log_file,"[ | ]( )+[0-9]+") & !str_detect(log_file,"Date:   ") | str_detect(log_file,"file changed") | str_detect(log_file,"files changed") )]

#we collect the commits information
commits<-list(stats_changed_files=c(),files=c())
i<-1
start<-i#initialization  the "start" position of the committed files
  while(i<=length(log_file)){
    
    if(str_detect(log_file[i],"file changed") | str_detect(log_file[i],"files changed")){
      # we have the end  position of the committed files
      end<-i
      files_committed<-log_file[start:end]
      #we check if there are some java file modified:
      #if there are java files committed we populate the commit information
      condition<- str_detect(files_committed,"/[A-Z]([A-z]|[0-9])*.java")
      condition2<- str_detect(files_committed,"file changed") | str_detect(files_committed,"files changed")
      if(sum(condition)>0){
       stats_changed_files<- files_committed[which(condition2)]
       files_committed <- files_committed[which(condition)]
       #we populate the commit messages
       pos<- length(commits$stats_changed_files)+1
       commits$stats_changed_files[pos] <- stats_changed_files
       commits$files[pos] <- paste(files_committed,collapse=" ")
      }
      # we update the new start position of the committed files
      start<-i+1
    }
    
    print(paste("Analyzing git log at line",i))
    i<-i+1
  }

#For each pair of microservices we compute the conceptual coupling (whether two files change together..)
initial_net<-list(FROM=c(),TO=c(),C1=c(),C2=c())
i<-1
for (i in 1: (length(microservices_info$Microservice)-1))
{
  classes_microservice_i <- microservices_info_classes$microservice_file[which(microservices_info_classes$microservice == microservices_info$Microservice[i])]
  j<-2
  for (j in 2:length(microservices_info$Microservice))
  {
    classes_microservice_j <- microservices_info_classes$microservice_file[which(microservices_info_classes$microservice == microservices_info$Microservice[j])]
    c1<-1
    for (c1 in 1: (length(classes_microservice_i)))
    {
      classes_microservice_i <- microservices_info_classes$microservice_file[which(microservices_info_classes$microservice == microservices_info$Microservice[i])]
      c2<-1
      for (c2 in 1: (length(classes_microservice_j)))
      {
        #if the classes co-change
        condition1<- str_detect(commits$files,classes_microservice_i[c1]) & str_detect(commits$files,classes_microservice_j[c2])
        if(sum(condition1)>0){
          percentage_of_co_changes<- sum(condition1)/sum(str_detect(commits$files,classes_microservice_i[c1]))
          #if the classes co-change for a certain percentage of commits...
          if(percentage_of_co_changes>0.40)
          {
          #print(paste("cases",sum(condition)))
          pos <- length(initial_net$FROM)+1
          initial_net$FROM[pos] <- as.character(microservices_info$Microservice[i])
          initial_net$TO[pos] <- as.character(microservices_info$Microservice[j])
          initial_net$C1[pos] <- classes_microservice_i[c1]
          initial_net$C2[pos] <- classes_microservice_j[c2]
         }
        }
      }
     }
  }
  print(paste("Identified conceptual links related to microservice",i, "out of",length(microservices_info$Microservice),"microservices"))
}

tedges1<- initial_net

#no  match found, we can't compute the metrics
if(length(tedges1$TO)==0)
 {
  print("no  match found, we can't compute the metrics")
  a<- matrix(nrow = length(microservices_info$Microservice),ncol =  length(microservices_info$Microservice),data = 0)
  colnames(a)<-microservices_info$Microservice
  rownames(a)<-microservices_info$Microservice
  gplot(a,displaylabels = TRUE)
  pdf(graph_path, width=width, height=height)
  gplot(a,displaylabels = TRUE)
  dev.off()
  coupling<-rep(0,length(microservices_info$Microservice))
  
  print(paste("Generated graph related to Semantic Coupling"))
  }

# some matches found, we can compute the metrics
if(length(tedges1$TO)>0)
{
tedges<- as.data.frame(tedges1)
#we remove the wrong links...
tedges$C1<-NULL
tedges$C2<-NULL
tedges$similarity<-NULL

tedges$FROM<-as.character(tedges$FROM)
tedges$TO<-as.character(tedges$TO)
tnodes<-unique(c(tedges$FROM,tedges$TO))

g<-graph.data.frame(tedges, directed=TRUE);
a<-get.adjacency(g); #adjacency matrix for sna
a<-as.matrix(a)
diag(a)<-0
#colnames(a)<-microservices_info$Microservice
#rownames(a)<-microservices_info$Microservice
vertex.color = rep("red", length(tnodes))
gplot(a,displaylabels = TRUE,xlab =  "Conceptual dependencies",edge.lty = TRUE, vertex.col  = vertex.color, boxed.labels = TRUE )

deg<-degree(a); #sna degree
# if there is any vector with "betweenness" >0 we recolor the graph...
if(sum(deg)>0)
{
  i<-1
  maximum<-max(deg)
  for (i in 1:length(deg)){
    if(deg[i] == maximum){
      m<-i
      vertex.color[i]<-"green"
    }
  }
  weighted_deg<- log10(((deg-min(deg))/(max(deg)-min(deg))+1)*4.25)
  gplot(a,displaylabels = TRUE,xlab =  "Conceptual dependencies",edge.lty = TRUE, vertex.col  = vertex.color, vertex.cex = weighted_deg,boxed.labels = TRUE)
}
names(deg)<-colnames(a)
print(deg)

bw<-betweenness(a); #sna betweenness
names(bw)<-colnames(a)
# if there is any vector with "betweenness" >0 we recolor the graph...
if(sum(bw)>0)
{
  i<-1
  for (i in 1:length(bw)){
    if(bw[i]>0){
      dependend_vertexes<-(which(as.numeric(a[,i])>0))
      vertex.color[dependend_vertexes]<- "blue"
      vertex.color[i]<-"yellow"
    }
  }
  gplot(a,displaylabels = TRUE,xlab =  "Conceptual dependencies", vertex.col  = vertex.color, vertex.cex = weighted_deg,boxed.labels = TRUE )
}
bw<- rev(sort(bw))
print(bw)


indegree<-degree(a, cmode="indegree"); #sna indegree 
names(indegree)<-colnames(a)
#indegree<- rev(sort(indegree))
print(indegree)

outdegree<-degree(a, cmode="outdegree"); #sna outdegree 
names(outdegree)<-colnames(a)
#outdegree<- rev(sort(outdegree))
print(outdegree)

coupling<- round(1-1/(deg),2) * #coupling based on the general degree
            ((1+outdegree)/(1+deg)) * #re-weighted based on the balance between outdegree and indegree
            (deg/max(deg))  #re-weighted based on the degree
#all weighted with the maximum...
coupling<- (coupling-min(coupling))/(max(coupling)-min(coupling));
#approx two decimal numbers...
coupling<- round(coupling,2)
names(coupling)<-colnames(a)
#outdegree<- rev(sort(outdegree))
print(coupling)
vertex.color[m]<-"green"


#graph.knn(graph(edges = paste(tedges$FROM,tedges$TO,sep="--"),directed = FALSE))

gplot(a,displaylabels = TRUE,xlab =  "Conceptual dependencies", vertex.col  = vertex.color, 
      vertex.cex = weighted_deg+coupling,label = paste(colnames(a)," (",coupling,")",sep=""),
      boxed.labels = TRUE)

pdf(graph_path, width=width, height=height)
gplot(a,displaylabels = TRUE,xlab =  "Conceptual dependencies", vertex.col  = vertex.color, 
      vertex.cex = weighted_deg+coupling,label = paste(colnames(a)," (",coupling,")",sep=""),
      boxed.labels = TRUE)
dev.off()

brokerage<-brokerage(a,as.factor(tnodes))
mydata2<-brokerage$raw.nli
gatekeeper_t2<-mydata2[,"b_IO"]
representative_t2<-mydata2[,"b_OI"]

print(paste("Generated graph related to Semantic Coupling"))
}

return(coupling)
}





