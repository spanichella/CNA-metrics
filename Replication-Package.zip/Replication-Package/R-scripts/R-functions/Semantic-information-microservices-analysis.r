#@Sebastiano Panichella

stopword_java<-c("abstract","default","package","synchronized","boolean","break","double","implements",
                 "protected","throw","byte","else","import","public","throws","instanceof","return",
                 "transient","catch","extends","int","short","try","char","final","interface","static",
                 "void","class","finally","long","float","native","super","while")

#FUNCTION "textual similarity"
computeSimilarityBetweenFiles<-function(classes_ij){
  if(length(classes_ij)>1){
  c<- 1
  con <- file(classes_ij[c], "r", blocking = FALSE)
  class<-readLines(con) # empty
  close(con)
  text<-c(paste(class,collapse=" ")) # initialization
  c<-2
  for (c in 2:length(classes_ij)){
    #prepare mock data
    con <- file(classes_ij[c], "r", blocking = FALSE)
    class<-readLines(con) # empty
    close(con)
    text <- c(text,paste(class,collapse=" "))
  }
  
  df <- data.frame(text,  stringsAsFactors = FALSE)
  
  # prepare corpus
  corpus <- Corpus(VectorSource(df$text))
  corpus <- tm_map(corpus, tolower)
  corpus <- tm_map(corpus, removePunctuation)
  corpus <- tm_map(corpus, function(x) removeWords(x, unique(c(stopword_java,stopwords("english")))))
  corpus <- tm_map(corpus, stemDocument, language = "english")
  corpus  # check corpus
  #  matrix representation of the documents
  td.mat <- as.matrix(TermDocumentMatrix(corpus))
  similarities<-cosine(td.mat)
  colnames(similarities)<- c(classes_ij)
  rownames(similarities)<- c(classes_ij)
  #we replace with zero the similarity in the diagonal of the matrix
  diag(similarities)<- diag(similarities)*0
   
  }
  
  if(length(classes_ij)<=1){
    similarities<-as.matrix(0.40)
  colnames(similarities)<- c(classes_ij)
  rownames(similarities)<- c(classes_ij)
  }
  
  return(similarities)
}

computeSemanticSimilarityBetweenFiles<-function(path_project,project_short_name,width,height){
  
  

graph_path<-paste(path_project,"/sem_graph.pdf",sep="")

#WE COMPUTED THE STRUCTURAL COUPLING

#let's collect all nodes of the microservices (can be one file or several set of files per microservice..)
path_microservices_info<-paste(path_project,"/Microservices-info.csv", sep="")
microservices_info<-read.csv(path_microservices_info)

microservices_info_classes<- list(microservice=c(), microservice_file=c())
i<-1
for (i in 1:length(microservices_info$Microservice)){
  #initialization<-
  location_folder_microservice<-path_project
  
   #CASE 1: microservices are located in precise folders
    if(microservices_info$Is_Folder[i]=="yes"){
      #all folders in the directory..
      location_folder_microservice <- list.dirs(path_project,full.names = microservices_info$Microservice[i],recursive = TRUE) 
      pattern <- paste("/",microservices_info$Microservice[i],sep="")
      #we detect the folder of the microservices, among all folders in the directory..
      location_folder_microservice<-location_folder_microservice[which(endsWith(location_folder_microservice,pattern))]
      location_folder_microservice<- location_folder_microservice[1]
      #we detect all class files in the folder of the microservices
      class_files<-list.files(location_folder_microservice,pattern = "*.java",recursive = TRUE,full.names = TRUE)
    }
    
    #CASE 2: microservices are actual class files
    if(microservices_info$Is_File[i]=="yes"){
      class_files<- list.files(as.character(microservices_info$Path_File[i]),pattern = as.character(microservices_info$Microservice[i]),recursive = TRUE,full.names = TRUE)
    }
    
      #we collect in the list the information about the class files related to the microservice
      c<-1
        for(c in 1:length(class_files))
        {
          
          pos<- length(microservices_info_classes$microservice)+1
          microservices_info_classes$microservice[pos] <- as.character(microservices_info$Microservice[i])
          microservices_info_classes$microservice_file[pos] <- class_files[c]   
        }
  
  print(paste("preprocessing",i, "out of", length(microservices_info$Microservice),"microservices"))
}

#For each pair of microservies we compute textual similarity between the 
#classes of the microservices...
initial_net<-list(FROM=c(),TO=c(),C1=c(),C2=c(),similarity=c())

i<-1
 for (i in 1: (length(microservices_info$Microservice)-1))
 {
   classes_microservice_i <- microservices_info_classes$microservice_file[which(microservices_info_classes$microservice == microservices_info$Microservice[i])]
   j<-2
   for (j in 2:length(microservices_info$Microservice))
   { 
     #we compute the similarities between the classes of the microservice "i"
     similarities_i<-computeSimilarityBetweenFiles(classes_microservice_i)
     # we compute the average the similarities between the classes of the microservice "i"
     #CASE 1: microservices are located in precise folders
     if(microservices_info$Is_Folder[i]=="yes")
     {mean_similarities_i<-mean(similarities_i[lower.tri(similarities_i)])}
     #CASE 2: microservices are actual class files
     if(microservices_info$Is_File[i]=="yes")
     {mean_similarities_i<-as.numeric(similarities_i)}
     
     
     if(i<j)
       {
       print(paste(i,",",j))
       #we compute the similarity between the classes of the microservices and 
       classes_microservice_j <- microservices_info_classes$microservice_file[which(microservices_info_classes$microservice == microservices_info$Microservice[j])]
       classes_ij<- c(classes_microservice_i,classes_microservice_j)
       similarities<-computeSimilarityBetweenFiles(classes_ij)
       #we consider of the table the rows related to the classes of the microservice "i"
       #CASE 1: microservices are located in precise folders
       if(microservices_info$Is_Folder[i]=="yes")
       {rows<-1:length(classes_microservice_i)
        cols<- (length(classes_microservice_i)+1):length(similarities[1,])
        similarities <- similarities[rows,cols]
       }
       #CASE 2: microservices are actual class files
       if(microservices_info$Is_File[i]=="yes")
       {rows<-1
        cols<- 2
        similarities <- similarities[rows,cols]
        similarities<-as.matrix(similarities)
       }
       
       
       # we try to populate the link by considering the cases in which
       # the textual similarity among classes of different microservices is higher than
       # the average of similarity of classes in the microservice "i"
         s<-1
         for(s in 1:length(classes_microservice_i)) {
           #cases in which the textual similarity is higher than the average...
           positive_cases <- which(similarities[s,]>=mean_similarities_i)
           #we use this information to 
           if( length(positive_cases)>0){
             p<- 1
             for(p in 1:length(positive_cases)) {
               pos <- length(initial_net$FROM)+1
               initial_net$FROM[pos] <- as.character(microservices_info$Microservice[i])
               initial_net$TO[pos] <- as.character(microservices_info$Microservice[j])
               initial_net$C1[pos] <- classes_microservice_i[s]
               initial_net$C2[pos] <- classes_microservice_j[positive_cases[p]]
               initial_net$similarity[pos] <- similarities[s,positive_cases[p]]
             }
           }
         }
         
      }
    }
   
   print(paste("computing textual similarity between microservice",i, "and microservice",j))
  }


tedges1<- initial_net

#no  match found, we can't compute the metrics
if(length(tedges1$TO)==0)
 {
  print("no  match found, we can't compute the metrics")
  a<- matrix(nrow = length(microservices_info$Microservice),ncol =  length(microservices_info$Microservice),data = 0)
  colnames(a)<-microservices_info$Microservice
  rownames(a)<-microservices_info$Microservice
  gplot(a,displaylabels = TRUE)
  pdf(graph_path, width=width, height=height)
  gplot(a,displaylabels = TRUE)
  dev.off()
  print(paste("Generated graph related to Semantic Coupling"))
  coupling<-rep(0,length(microservices_info$Microservice))
  
  }

# some matches found, we can compute the metrics
if(length(tedges1$TO)>0)
{
tedges<- as.data.frame(tedges1)
#we remove the wrong links...
tedges$C1<-NULL
tedges$C2<-NULL
tedges$similarity<-NULL

tedges$FROM<-as.character(tedges$FROM)
tedges$TO<-as.character(tedges$TO)
tnodes<-unique(c(tedges$FROM,tedges$TO))

g<-graph.data.frame(tedges, directed=TRUE);
a<-get.adjacency(g); #adjacency matrix for sna
a<-as.matrix(a)
diag(a)<-0
#colnames(a)<-microservices_info$Microservice
#rownames(a)<-microservices_info$Microservice
vertex.color = rep("red", length(tnodes))
gplot(a,displaylabels = TRUE,xlab =  "Semantic dependencies",edge.lty = TRUE, vertex.col  = vertex.color, boxed.labels = TRUE )

deg<-degree(a); #sna degree
# if there is any vector with "betweenness" >0 we recolor the graph...
if(sum(deg)>0)
{
  i<-1
  maximum<-max(deg)
  for (i in 1:length(deg)){
    if(deg[i] == maximum){
      m<-i
      vertex.color[i]<-"green"
    }
  }
  weighted_deg<- log10(((deg-min(deg))/(max(deg)-min(deg))+1)*4.25)
  gplot(a,displaylabels = TRUE,xlab =  "Semantic dependencies",edge.lty = TRUE, vertex.col  = vertex.color, vertex.cex = weighted_deg,boxed.labels = TRUE)
}
names(deg)<-colnames(a)
print(deg)

bw<-betweenness(a); #sna betweenness
names(bw)<-colnames(a)
# if there is any vector with "betweenness" >0 we recolor the graph...
if(sum(bw)>0)
{
  i<-1
  for (i in 1:length(bw)){
    if(bw[i]>0){
      dependend_vertexes<-(which(as.numeric(a[,i])>0))
      vertex.color[dependend_vertexes]<- "blue"
      vertex.color[i]<-"yellow"
    }
  }
  gplot(a,displaylabels = TRUE,xlab =  "Semantic dependencies", vertex.col  = vertex.color, vertex.cex = weighted_deg,boxed.labels = TRUE )
}
bw<- rev(sort(bw))
print(bw)


indegree<-degree(a, cmode="indegree"); #sna indegree 
names(indegree)<-colnames(a)
#indegree<- rev(sort(indegree))
print(indegree)

outdegree<-degree(a, cmode="outdegree"); #sna outdegree 
names(outdegree)<-colnames(a)
#outdegree<- rev(sort(outdegree))
print(outdegree)

coupling<- round(1-1/(deg),2) * #coupling based on the general degree
            ((1+outdegree)/(1+deg)) * #re-weighted based on the balance between outdegree and indegree
            (deg/max(deg))  #re-weighted based on the degree
#all weighted with the maximum...
coupling<- (coupling-min(coupling))/(max(coupling)-min(coupling));
#approx two decimal numbers...
coupling<- round(coupling,2)
names(coupling)<-colnames(a)
#outdegree<- rev(sort(outdegree))
print(coupling)
vertex.color[m]<-"green"

#graph.knn(graph(edges = paste(tedges$FROM,tedges$TO,sep="--"),directed = FALSE))

gplot(a,displaylabels = TRUE,xlab =  "Semantic dependencies", vertex.col  = vertex.color, 
      vertex.cex = weighted_deg+coupling,label = paste(colnames(a)," (",coupling,")",sep=""),
      boxed.labels = TRUE)

pdf(graph_path, width=width, height=height)
gplot(a,displaylabels = TRUE,xlab =  "Semantic dependencies", vertex.col  = vertex.color, 
      vertex.cex = weighted_deg+coupling,label = paste(colnames(a)," (",coupling,")",sep=""),
      boxed.labels = TRUE)
dev.off()

brokerage<-brokerage(a,as.factor(tnodes))
mydata2<-brokerage$raw.nli
gatekeeper_t2<-mydata2[,"b_IO"]
representative_t2<-mydata2[,"b_OI"]

print(paste("Generated graph related to Semantic Coupling"))
}

return(coupling)
}





