#@Sebastiano Panichella

computeStructuralSimilarityBetweenFiles<-function(path_project,project_short_name,width,height){


graph_path<-paste(path_project,"/str_graph.pdf",sep="")

#WE COMPUTED THE STRUCTURAL COUPLING

#let's collect all nodes of the microservices (can be one file or several set of files per microservice..)
path_microservices_info<-paste(path_project,"/Microservices-info.csv", sep="")
microservices_info<-read.csv(path_microservices_info)

microservices_info_classes<- list(microservice=c(), microservice_file=c())
microservices_classes_links<- list(microservice=c(), links_file=c())
i<-1
for (i in 1:length(microservices_info$Microservice)){
  #initialization<-
  location_folder_microservice<-path_project
  
   #CASE 1: microservices are located in precise folders
    if(microservices_info$Is_Folder[i]=="yes"){
      #all folders in the directory..
      location_folder_microservice <- list.dirs(path_project,full.names = microservices_info$Microservice[i],recursive = TRUE) 
      pattern <- paste("/",microservices_info$Microservice[i],sep="")
      #we detect the folder of the microservices, among all folders in the directory..
      location_folder_microservice<-location_folder_microservice[which(endsWith(location_folder_microservice,pattern))]
      location_folder_microservice<- location_folder_microservice[1]
      #we detect all class files in the folder of the microservices
      class_files<-list.files(location_folder_microservice,pattern = "*.class",recursive = TRUE)
    }
    
    #CASE 2: microservices are actual class files
    if(microservices_info$Is_File[i]=="yes"){
      class_files<- str_replace( as.character(microservices_info$Microservice[i]) , "java","class")
    }
    
      #we collect in the list the information about the class files related to the microservice
      c<-1
        for(c in 1:length(class_files))
        {
          
          pos<- length(microservices_info_classes$microservice)+1
          microservices_info_classes$microservice[pos] <- as.character(microservices_info$Microservice[i])
          microservices_info_classes$microservice_file[pos] <- class_files[c]   
        }
      #we collect the dependencies between class files related to the microservice
      #command<- paste("jdeps   -v -apionly  -R  ", #to extract call at APIs level
      command<- paste("jdeps   -v   -R  ",  #to detect all class level calls
                      location_folder_microservice,
                      " > ",location_folder_microservice, "/microservice-links.txt", sep="")
      #we write the dependencies information between class files related to the microservice using the system call   
      system(command)
      # we save the file containing information about the links of each microservice
      pos<- length(microservices_classes_links$microservice)+1
      microservices_classes_links$microservice[pos]<-as.character(microservices_info$Microservice[i])
      microservices_classes_links$links_file[pos]<-  paste(location_folder_microservice, "/microservice-links.txt", sep="")
     
    print(paste("preprocessing",i, "out of", length(microservices_info$Microservice),"microservices"))
}

#for each microservice we consider only links related to the project:
initial_net<-list(FROM=c(),TO=c())
# dependencies information between each microservice and other class files are stored in "initial_net"
i<-1
  for (i in 1: length(microservices_classes_links$links_file)){
    links<- readLines(microservices_classes_links$links_file[i])
    
    #CASE 1: microservices are located in precise folders
    if(microservices_info$Is_Folder[i]=="yes"){
    # we extrac the right part of the links... ("-> ...")
    links2 <- str_sub(links,str_locate(links,"->")[,2]+2, str_length(links))
    links2 <- links2[which(str_detect(links2,project_short_name))]
    links2<- str_replace_all(links2,"  "," ")
    # we detect the actual class names in the resulting list
     l<-1
     for(l in 1:length(links2))
      {
      links2[l]<- strsplit(links2[l],split=" ")[[1]][1]
      pos<- length(initial_net$FROM)+1
      initial_net$FROM[pos] <- microservices_classes_links$microservice[i]
      initial_net$TO[pos]   <- links2[l]
       }
     }
    
    #CASE 2: microservices are actual class files
    if(microservices_info$Is_File[i]=="yes"){
      links2 <- links[which(str_detect(links,str_replace(microservices_classes_links$microservice[i],".java"," ")))]
      links2 <- links2[which(str_count(links2,project_short_name)>=2)]
      #we keep the right and left side (vertices) of the edge
      links2R <- str_sub(links2,str_locate(links2,"->")[,2]+2, str_length(links2))
      links2R<- str_replace_all(links2R,"  "," ")
      links2L <- str_sub(links2,4, str_locate(links2,"->")[,2])
      links2L<- str_replace_all(links2L,"  "," ")
      # we detect the actual class names in the resulting list
      l<-1
      if(length(links2L)>0)
      for(l in 1:length(links2L))
      {
        links2L[l]<- strsplit(links2L[l],split=" ")[[1]][1]
        links2R[l]<- strsplit(links2R[l],split=" ")[[1]][1]
        pos<- length(initial_net$FROM)+1
        #we create a vectore representing the edge
        vect_edge<-c(links2L[l],links2R[l])
        #we determine which vector is the current microservice and replace its name
        microservice<-str_replace(microservices_classes_links$microservice[i],".java","")
        to_replace<- which(str_detect(vect_edge,microservice))
        vect_edge[to_replace]<-microservice
        initial_net$FROM[pos] <- vect_edge[1]
        initial_net$TO[pos]   <- vect_edge[2]
      }
    }
    print(paste("Identified structural links related to microservice",i, "out of",length(microservices_info$Microservice),"microservices"))
    
  }

#We have to replace the actual classes with the associated "microservices"
# thus, we first try to make class names similar between the file reporting the links information
microservices_info_classes$microservice_file_preprocessed<- str_replace_all(microservices_info_classes$microservice_file,"/",".")
microservices_info_classes$microservice_file_preprocessed<- str_replace_all(microservices_info_classes$microservice_file_preprocessed,"target.classes.","")
microservices_info_classes$microservice_file_preprocessed<- str_replace(microservices_info_classes$microservice_file_preprocessed,".class","")
# then we replace class names, when possible, with the actual microservices

tedges1<- initial_net
tedges1$TO2<-1:length(tedges1$TO)*0
tedges1$FROM2<-1:length(tedges1$FROM)*0
i<-1
for(i in 1:length(microservices_info_classes$microservice)){
  
  string_to_match<-microservices_info_classes$microservice_file_preprocessed[i]
  #positions that matches:
  if(str_detect(microservices_info_classes$microservice_file_preprocessed[i],project_short_name))
  {
    string_to_match <- str_sub(string_to_match,str_locate(string_to_match,project_short_name)[1]+str_length(project_short_name)+1 , str_length(string_to_match))
  }
  positions<-which(str_detect(tedges1$TO,string_to_match))
  
  if( length(positions) >0)
    {
     tedges1$TO2[positions]<- microservices_info_classes$microservice[i]
     } 
  #positions that matches:
  positions<-which(str_detect(tedges1$FROM,string_to_match))
  
   if( length(positions) >0)
   {
     tedges1$FROM2[positions]<- microservices_info_classes$microservice[i]
    } 
   #CASE 1: microservices are located in precise folders
   if(microservices_info$Is_Folder[1]=="yes"){
     tedges1$FROM2<-tedges1$FROM
    }
  
  }

#no  match found, we can't compute the metrics
if(sum(tedges1$TO2!=0 & tedges1$FROM2!=0)==0)
 {
  print("no  match found, we can't compute the metrics")
  a<- matrix(nrow = length(microservices_info$Microservice),ncol =  length(microservices_info$Microservice),data = 0)
  colnames(a)<-microservices_info$Microservice
  rownames(a)<-microservices_info$Microservice
  # we write in a file the graph...
  gplot(a,displaylabels = TRUE)
  pdf(graph_path, width=width, height=height)
  gplot(a,displaylabels = TRUE)
  dev.off()
  coupling<-rep(0,length(microservices_info$Microservice))
  
  print(paste("Generated graph related to Semantic Coupling"))
  }

# some matches found, we can compute the metrics
if(sum(tedges1$TO2!=0 & tedges1$FROM2!=0 )!=0)
{
tedges<- as.data.frame(tedges1)
#we remove the wrong links...
tedges<- tedges[which(tedges1$TO2!=0 & tedges1$FROM2!=0 ),]
tedges$TO<-tedges$TO2
tedges$TO2<-NULL
tedges$FROM<-tedges$FROM2
tedges$FROM2<-NULL

tedges$FROM<-as.character(tedges$FROM)
tedges$TO<-as.character(tedges$TO)
tnodes<-unique(c(tedges$FROM,tedges$TO))

g<-graph.data.frame(tedges, directed=TRUE);
a<-get.adjacency(g); #adjacency matrix for sna
a<-as.matrix(a)
diag(a)<-0
#colnames(a)<-microservices_info$Microservice
#rownames(a)<-microservices_info$Microservice
vertex.color = rep("red", length(tnodes))
gplot(a,displaylabels = TRUE,xlab =  "Structural dependencies",edge.lty = TRUE, vertex.col  = vertex.color, boxed.labels = TRUE )

deg<-degree(a); #sna degree
# if there is any vector with "betweenness" >0 we recolor the graph...
if(sum(deg)>0)
{
  i<-1
  maximum<-max(deg)
  for (i in 1:length(deg)){
    if(deg[i] == maximum){
      vertex.color[i]<-"green"
    }
  }
  weighted_deg<- log10(((deg-min(deg))/(max(deg)-min(deg))+1)*4.25)
  gplot(a,displaylabels = TRUE,xlab =  "Structural dependencies",edge.lty = TRUE, vertex.col  = vertex.color, vertex.cex = weighted_deg,boxed.labels = TRUE)
}
names(deg)<-colnames(a)
print(deg)

bw<-betweenness(a); #sna betweenness
names(bw)<-colnames(a)
# if there is any vector with "betweenness" >0 we recolor the graph...
if(sum(bw)>0)
{
  i<-1
  for (i in 1:length(bw)){
    if(bw[i]>0){
      dependend_vertexes<-(which(as.numeric(a[,i])>0))
      vertex.color[dependend_vertexes]<- "blue"
      vertex.color[i]<-"yellow"
    }
  }
  gplot(a,displaylabels = TRUE,xlab =  "Structural dependencies", vertex.col  = vertex.color, vertex.cex = weighted_deg,boxed.labels = TRUE )
}
bw<- rev(sort(bw))
print(bw)


indegree<-degree(a, cmode="indegree"); #sna indegree 
names(indegree)<-colnames(a)
#indegree<- rev(sort(indegree))
print(indegree)

outdegree<-degree(a, cmode="outdegree"); #sna outdegree 
names(outdegree)<-colnames(a)
#outdegree<- rev(sort(outdegree))
print(outdegree)

coupling<- round(1-1/(deg),2) * #coupling based on the general degree
            ((1+outdegree)/(1+deg)) * #re-weighted based on the balance between outdegree and indegree
            (deg/max(deg))  #re-weighted based on the degree
#all weighted with the maximum...
coupling<- (coupling-min(coupling))/(max(coupling)-min(coupling));
#approx two decimal numbers...
coupling<- round(coupling,2)
names(coupling)<-colnames(a)
#outdegree<- rev(sort(outdegree))
print(coupling)

#graph.knn(graph(edges = paste(tedges$FROM,tedges$TO,sep="--"),directed = FALSE))

gplot(a,displaylabels = TRUE,xlab =  "Structural dependencies", vertex.col  = vertex.color, 
      vertex.cex = weighted_deg+coupling,label = paste(colnames(a)," (",coupling,")",sep=""),
      boxed.labels = TRUE)

pdf(graph_path, width=width, height=height)
gplot(a,displaylabels = TRUE,xlab =  "Structural dependencies", vertex.col  = vertex.color, 
      vertex.cex = weighted_deg+coupling,label = paste(colnames(a)," (",coupling,")",sep=""),
      boxed.labels = TRUE)
dev.off()


brokerage<-brokerage(a,as.factor(tnodes))
mydata2<-brokerage$raw.nli
gatekeeper_t2<-mydata2[,"b_IO"]
representative_t2<-mydata2[,"b_OI"]

print(paste("Generated graph related to Semantic Coupling"))
}

return(coupling)
}




